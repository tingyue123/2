# AI-Screen-Share

这是一个用于 Android 的应用，允许用户共享屏幕并将内容发送至自定义 AI 接口。

## 功能

- 屏幕共享（MediaProjection）
- 可配置 AI 接口 URL
- GitHub Actions 自动构建 APK

## 使用方法

1. 输入你的 AI 接口地址。
2. 点击“开始共享”按钮。
3. 屏幕共享启动后内容会通过接口上传。

默认接口：
```
https://aish.chatopens.vip/c/6845341f-5bbc-8003-9dfc-b5ced16fc272/api/chat
```