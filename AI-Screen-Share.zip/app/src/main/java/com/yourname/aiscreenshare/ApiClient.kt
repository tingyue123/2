package com.yourname.aiscreenshare

import okhttp3.*
import java.io.IOException

object ApiClient {
    fun sendData(apiUrl: String, data: ByteArray) {
        val client = OkHttpClient()
        val requestBody = RequestBody.create("application/octet-stream".toMediaTypeOrNull(), data)
        val request = Request.Builder()
            .url(apiUrl)
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                response.close()
            }
        })
    }
}